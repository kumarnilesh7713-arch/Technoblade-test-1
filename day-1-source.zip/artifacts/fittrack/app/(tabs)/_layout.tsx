import { Feather, Ionicons } from "@expo/vector-icons";
import { BlurView } from "expo-blur";
import { isLiquidGlassAvailable } from "expo-glass-effect";
import { Tabs } from "expo-router";
import { Icon, Label, NativeTabs } from "expo-router/unstable-native-tabs";
import { SymbolView } from "expo-symbols";
import React from "react";
import { Platform, StyleSheet, View, useColorScheme } from "react-native";

import { useColors } from "@/hooks/useColors";

const TAB_DEFS = [
  { name: "index", title: "Home", sf: { default: "house", selected: "house.fill" } as const, feather: "home" as const },
  { name: "challenges", title: "Challenges", sf: { default: "flame", selected: "flame.fill" } as const, feather: "zap" as const },
  { name: "workouts", title: "Workouts", sf: { default: "dumbbell", selected: "dumbbell.fill" } as const, feather: "list" as const },
  { name: "history", title: "History", sf: { default: "clock", selected: "clock.fill" } as const, feather: "clock" as const },
  { name: "profile", title: "Profile", sf: { default: "person", selected: "person.fill" } as const, feather: "user" as const },
];

function NativeTabLayout() {
  return (
    <NativeTabs>
      {TAB_DEFS.map((t) => (
        <NativeTabs.Trigger key={t.name} name={t.name}>
          <Icon sf={t.sf} />
          <Label>{t.title}</Label>
        </NativeTabs.Trigger>
      ))}
    </NativeTabs>
  );
}

function ClassicTabLayout() {
  const colors = useColors();
  const colorScheme = useColorScheme();
  const isDark = colorScheme === "dark";
  const isIOS = Platform.OS === "ios";
  const isWeb = Platform.OS === "web";

  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.mutedForeground,
        headerShown: false,
        tabBarShowLabel: true,
        tabBarLabelStyle: {
          fontSize: 10,
          fontFamily: "Inter_600SemiBold",
          letterSpacing: 0.4,
          marginTop: 2,
        },
        sceneStyle: { backgroundColor: colors.background },
        tabBarStyle: {
          position: "absolute",
          backgroundColor: isIOS ? "transparent" : colors.background,
          borderTopWidth: isWeb ? 1 : StyleSheet.hairlineWidth,
          borderTopColor: colors.border,
          elevation: 0,
          ...(isWeb ? { height: 84, paddingTop: 6 } : {}),
        },
        tabBarBackground: () =>
          isIOS ? (
            <BlurView
              intensity={100}
              tint={isDark ? "dark" : "light"}
              style={StyleSheet.absoluteFill}
            />
          ) : (
            <View
              style={[
                StyleSheet.absoluteFill,
                { backgroundColor: colors.background },
              ]}
            />
          ),
      }}
    >
      {TAB_DEFS.map((t) => (
        <Tabs.Screen
          key={t.name}
          name={t.name}
          options={{
            title: t.title,
            tabBarIcon: ({ color, focused }) =>
              isIOS ? (
                <SymbolView
                  name={focused ? t.sf.selected : t.sf.default}
                  tintColor={color}
                  size={24}
                />
              ) : (
                <Feather name={t.feather} size={22} color={color} />
              ),
          }}
        />
      ))}
    </Tabs>
  );
}

export default function TabLayout() {
  if (isLiquidGlassAvailable()) {
    return <NativeTabLayout />;
  }
  return <ClassicTabLayout />;
}

// Avoid unused import warning when SymbolView path is taken
void Ionicons;
