import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { useLocalSearchParams, useRouter } from "expo-router";
import React from "react";
import {
  Alert,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { IconButton } from "@/components/IconButton";
import { RouteTrace } from "@/components/RouteTrace";
import { SplitsTable } from "@/components/SplitsTable";
import { useUnits } from "@/contexts/UnitsContext";
import { useWorkouts } from "@/contexts/WorkoutsContext";
import { useColors } from "@/hooks/useColors";
import {
  distanceUnitLabel,
  formatDate,
  formatDistance,
  formatDuration,
  formatNumber,
  formatPace,
  formatTime,
  paceUnitLabel,
} from "@/lib/format";

const ACTIVITY_ICON: Record<string, keyof typeof Ionicons.glyphMap> = {
  run: "walk-outline",
  cycle: "bicycle-outline",
  walk: "footsteps-outline",
};

export default function LogDetail() {
  const colors = useColors();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { units } = useUnits();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { getById, deleteWorkout } = useWorkouts();
  const workout = getById(id);

  if (!workout) {
    return (
      <View style={[styles.empty, { backgroundColor: colors.background }]}>
        <Text style={{ color: colors.foreground, fontFamily: "Inter_700Bold" }}>
          Activity not found
        </Text>
        <Pressable onPress={() => router.back()} style={{ padding: 12 }}>
          <Text style={{ color: colors.primary, fontFamily: "Inter_700Bold" }}>Go back</Text>
        </Pressable>
      </View>
    );
  }

  const accent =
    workout.activity === "run"
      ? colors.runColor
      : workout.activity === "cycle"
        ? colors.cycleColor
        : colors.walkColor;

  const handleDelete = () => {
    const doDelete = () => {
      deleteWorkout(workout.id);
      router.back();
    };
    if (Platform.OS === "web") {
      if (confirm("Delete this activity?")) doDelete();
    } else {
      Alert.alert("Delete activity?", "This cannot be undone.", [
        { text: "Cancel", style: "cancel" },
        { text: "Delete", style: "destructive", onPress: doDelete },
      ]);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 60 }}
      >
        <LinearGradient
          colors={
            colors.scheme === "dark"
              ? [accent + "40", "rgba(10,14,26,0)"]
              : [accent + "26", "rgba(255,255,255,0)"]
          }
          start={{ x: 0, y: 0 }}
          end={{ x: 0, y: 1 }}
          style={[styles.hero, { paddingTop: insets.top + 8 }]}
        >
          <View style={styles.heroBar}>
            <IconButton
              icon="chevron-back"
              onPress={() => router.back()}
              accessibilityLabel="Back"
            />
            <IconButton
              icon="trash-outline"
              onPress={handleDelete}
              color={colors.destructive}
              accessibilityLabel="Delete"
            />
          </View>
          <View style={{ paddingHorizontal: 22, marginTop: 4 }}>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
              <View style={[styles.icon, { backgroundColor: accent }]}>
                <Ionicons
                  name={ACTIVITY_ICON[workout.activity]!}
                  size={20}
                  color={colors.primaryForeground}
                />
              </View>
              <Text
                style={{
                  color: accent,
                  fontFamily: "Inter_700Bold",
                  fontSize: 11,
                  letterSpacing: 1.4,
                  textTransform: "uppercase",
                }}
              >
                {workout.activity}
              </Text>
            </View>
            <Text
              style={{
                color: colors.foreground,
                fontFamily: "Inter_700Bold",
                fontSize: 28,
                marginTop: 10,
                letterSpacing: -0.6,
              }}
            >
              {workout.title}
            </Text>
            <Text
              style={{
                color: colors.mutedForeground,
                fontFamily: "Inter_500Medium",
                fontSize: 13,
                marginTop: 4,
              }}
            >
              {formatDate(workout.startedAt)} • {formatTime(workout.startedAt)}
            </Text>
          </View>

          <View style={styles.bigStat}>
            <Text
              style={{
                color: colors.mutedForeground,
                fontFamily: "Inter_600SemiBold",
                fontSize: 11,
                letterSpacing: 1.4,
                textTransform: "uppercase",
              }}
            >
              Total distance
            </Text>
            <Text
              style={{
                color: colors.foreground,
                fontFamily: "Inter_700Bold",
                fontSize: 64,
                letterSpacing: -2,
                marginTop: -4,
              }}
              numberOfLines={1}
              adjustsFontSizeToFit
            >
              {formatDistance(workout.distanceMeters, units)}
              <Text style={{ fontSize: 22, color: colors.mutedForeground }}>
                {" "}
                {distanceUnitLabel(units)}
              </Text>
            </Text>
          </View>
        </LinearGradient>

        <View style={[styles.metricsGrid, { paddingHorizontal: 22 }]}>
          <Metric label="Time" value={formatDuration(workout.durationSeconds)} />
          <Metric
            label={`Pace ${paceUnitLabel(units)}`}
            value={formatPace(workout.averagePace, units)}
          />
          <Metric label="Calories" value={formatNumber(workout.caloriesBurned)} />
          <Metric label="Elevation" value={`${formatNumber(workout.elevationGainMeters)} m`} />
        </View>

        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Route</Text>
        <View style={{ paddingHorizontal: 22 }}>
          <RouteTrace points={workout.route} accent={accent} height={220} />
        </View>

        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Splits</Text>
        <View style={{ paddingHorizontal: 22 }}>
          <SplitsTable splits={workout.splits} accent={accent} />
        </View>

        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Highlights</Text>
        <View style={{ paddingHorizontal: 22, gap: 10 }}>
          <Highlight
            icon="trophy-outline"
            iconColor={accent}
            title="Activity logged"
            body={`Saved to your history with full route and stats.`}
          />
          {workout.splits.length > 0 ? (
            <Highlight
              icon="speedometer-outline"
              iconColor={colors.accent}
              title="Fastest split"
              body={`Split ${
                workout.splits.reduce((best, s) => (s.pace < best.pace ? s : best)).index
              } at ${formatPace(
                workout.splits.reduce((best, s) => (s.pace < best.pace ? s : best)).pace,
                units,
              )} ${paceUnitLabel(units)}`}
            />
          ) : null}
          <Highlight
            icon="trending-up-outline"
            iconColor={colors.ringMinutes}
            title="Elevation gained"
            body={`+${formatNumber(workout.elevationGainMeters)} m climbed`}
          />
        </View>
      </ScrollView>
    </View>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  const colors = useColors();
  return (
    <View
      style={[
        styles.metric,
        { backgroundColor: colors.card, borderColor: colors.border, borderRadius: 18 },
      ]}
    >
      <Text
        style={{
          color: colors.mutedForeground,
          fontSize: 10,
          letterSpacing: 1.2,
          fontFamily: "Inter_600SemiBold",
          textTransform: "uppercase",
        }}
      >
        {label}
      </Text>
      <Text
        style={{
          color: colors.foreground,
          fontSize: 22,
          fontFamily: "Inter_700Bold",
          marginTop: 4,
          letterSpacing: -0.4,
        }}
        numberOfLines={1}
        adjustsFontSizeToFit
      >
        {value}
      </Text>
    </View>
  );
}

function Highlight({
  icon,
  iconColor,
  title,
  body,
}: {
  icon: keyof typeof Ionicons.glyphMap;
  iconColor: string;
  title: string;
  body: string;
}) {
  const colors = useColors();
  return (
    <View
      style={[
        styles.highlight,
        { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius },
      ]}
    >
      <View style={[styles.hIcon, { backgroundColor: iconColor + "1F" }]}>
        <Ionicons name={icon} size={18} color={iconColor} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={{ color: colors.foreground, fontFamily: "Inter_700Bold", fontSize: 14 }}>
          {title}
        </Text>
        <Text
          style={{
            color: colors.mutedForeground,
            fontFamily: "Inter_500Medium",
            fontSize: 12,
            marginTop: 2,
          }}
        >
          {body}
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  hero: {
    paddingBottom: 18,
  },
  heroBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 12,
  },
  icon: {
    width: 36,
    height: 36,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  bigStat: {
    paddingHorizontal: 22,
    marginTop: 16,
  },
  empty: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
  },
  metricsGrid: {
    marginTop: 4,
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
  },
  metric: {
    flexBasis: "47%",
    flexGrow: 1,
    padding: 14,
    borderWidth: StyleSheet.hairlineWidth,
  },
  sectionTitle: {
    paddingHorizontal: 22,
    fontSize: 18,
    fontFamily: "Inter_700Bold",
    letterSpacing: -0.2,
    marginTop: 28,
    marginBottom: 12,
  },
  highlight: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    padding: 14,
    borderWidth: StyleSheet.hairlineWidth,
  },
  hIcon: {
    width: 38,
    height: 38,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
});
